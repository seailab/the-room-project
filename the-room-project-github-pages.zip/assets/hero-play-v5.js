'use strict';
(() => {
 const scenes=[...document.querySelectorAll('[data-hero-art]')];if(!scenes.length)return;
 const calm=matchMedia('(prefers-reduced-motion: reduce)'),fine=matchMedia('(hover:hover) and (pointer:fine)');
 const awake=scene=>scene.classList.toggle('art-awake',scene.dataset.inView==='true'&&!document.hidden&&!calm.matches);
 const syncCta=()=>{const hide=scenes.some(scene=>scene.dataset.inView==='true'&&scene.querySelector('[data-art-flip]'));document.body.classList.toggle('hero-art-in-view',hide);const cta=document.querySelector('.mobile-project-cta');if(cta){cta.tabIndex=hide?-1:0;if(hide)cta.setAttribute('aria-hidden','true');else cta.removeAttribute('aria-hidden')}};
 const observer='IntersectionObserver'in window?new IntersectionObserver(entries=>{entries.forEach(({target,isIntersecting})=>{target.dataset.inView=String(isIntersecting);awake(target)});syncCta()},{threshold:.08}):null;
 scenes.forEach(scene=>{
  let frame=0,point=null;
  const reset=()=>{cancelAnimationFrame(frame);frame=0;point=null;scene.style.removeProperty('--art-x');scene.style.removeProperty('--art-y')};
  scene.addEventListener('pointermove',event=>{if(calm.matches||!fine.matches||event.pointerType==='touch'||scene.dataset.artPointer!=='true')return;const r=scene.getBoundingClientRect();point={x:((event.clientX-r.left)/r.width-.5)*14,y:((event.clientY-r.top)/r.height-.5)*12};if(frame)return;frame=requestAnimationFrame(()=>{if(point){scene.style.setProperty('--art-x',point.x.toFixed(2)+'px');scene.style.setProperty('--art-y',point.y.toFixed(2)+'px')}frame=0})});
  scene.addEventListener('pointerleave',reset);calm.addEventListener('change',()=>{reset();awake(scene)});
  scene.querySelectorAll('[data-art-flip]').forEach(button=>button.addEventListener('click',()=>{const flip=button.getAttribute('aria-pressed')!=='true';button.setAttribute('aria-pressed',String(flip));button.querySelector('.hero-memory-front').setAttribute('aria-hidden',String(flip));button.querySelector('.hero-memory-back').setAttribute('aria-hidden',String(!flip))}));
  if(observer)observer.observe(scene);else{scene.dataset.inView='true';awake(scene)}
 });
 document.addEventListener('visibilitychange',()=>scenes.forEach(awake));
 syncCta();
})();
